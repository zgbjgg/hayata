defmodule LoadExamples do
  def load do
    "examples/hayata_*_example.ex"
    |> Path.wildcard()
    |> Enum.reduce_while(:ok, &load_file/2)
  end

  defp load_file(file, :ok) do
    case Code.require_file(file) do
      _loaded_modules ->
        {:cont, :ok}
    end
  rescue
    error ->
      {:halt, {:error, {:load_failed, file, error}}}
  end
end
