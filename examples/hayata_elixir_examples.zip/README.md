# Hayata Elixir examples

These files are Elixir translations of the agent examples in `examples/` on branch `ex`.

## Files

- `hayata_cycle_example.ex`
- `hayata_parallel_example.ex`
- `hayata_rag_example.ex`
- `hayata_router_decision_example.ex`
- `hayata_stream_example.ex`
- `hayata_telemetry_example.ex`
- `hayata_weather_agent_example.ex`
- `hayata_weather_agent_stream_example.ex`
- `load_examples.ex` (manual loader utility; not an agent DSL module)

The already validated `hayata_simple_example.ex` is not duplicated here.

## Loading

Place the files under the project's `examples/` directory. They are standalone example modules; they are not automatically compiled by Mix unless that directory is added to the project compilation paths or the files are loaded explicitly.

Run a module with, for example:

```bash
mix run -e 'Code.require_file("examples/load_examples.ex"); :ok = LoadExamples.load(); IO.inspect(HayataCycleExample.run(), pretty: true)'
mix run -e 'Code.require_file("examples/load_examples.ex"); :ok = LoadExamples.load(); IO.inspect(HayataParallelExample.run(), pretty: true)'
mix run -e 'Code.require_file("examples/load_examples.ex"); :ok = LoadExamples.load(); IO.inspect(HayataRouterDecisionExample.run("hola"), pretty: true)'
mix run -e 'Code.require_file("examples/load_examples.ex"); :ok = LoadExamples.load(); IO.inspect(HayataStreamExample.run(), pretty: true)'
```

The RAG and weather examples require `OPENAI_API_KEY`.

`HayataTelemetryExample` is a telemetry helper, not an agent definition, so it has no `agent do` block. Call `HayataTelemetryExample.attach/0` and `HayataTelemetryExample.detach/0`.

`load_examples.erl` is an Erlang compiler/loader utility, not an agent. Its Elixir counterpart `load_examples.ex` loads the Elixir example files explicitly with `Code.require_file/1`; it does not use the agent DSL because it is not an agent.

## Validation status

These are source translations for review. They have not been run against the user's local checkout. Validate each file before considering the port complete.
